/**
 * 
 */
package com.marketplace.exception;

/**
 * @author arnab
 *
 */
public class MarketPlaceException extends Exception {

	private static final long serialVersionUID = 1L;

	public MarketPlaceException(String message) {
		super(message);
	}

	
}
